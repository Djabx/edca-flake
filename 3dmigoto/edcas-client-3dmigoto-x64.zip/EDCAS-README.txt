EDCAS 3DMigoto bundle (3DMigoto 1.4.9, x64)

What this is
  The official 3DMigoto 1.4.9 x64 files, for Elite Dangerous (Odyssey), with one change:
  d3d11.dll is built by EDCAS with a patch that reads shader parameters from a file
  (ShaderFixes\edcas_params.txt) while the game runs, so EDCAS can change them live.
  Every other file is unchanged from the official release.

How to use it
  Open EDCAS, Settings -> Game Graphics -> Shader Mods. It installs these files into the game
  folder (Products/elite-dangerous-odyssey-64) and sets the shaders up. Doing it by hand: copy
  everything next to this file into the game folder, except this README and the source folder.

Licence and source
  3DMigoto is licensed under the GNU General Public License v3.0 (source/LICENSE.GPL.txt).
  The patch EDCAS applies (source/params-file.patch) and the script that builds d3d11.dll from
  it (source/build.sh, with source/case_shim.py) are in the source folder; they apply to the
  unmodified 3DMigoto 1.4.9 source from https://github.com/bo3b/3Dmigoto (tag 1.4.9).
  3DMigoto is the work of its authors; this bundle is not affiliated with them.
