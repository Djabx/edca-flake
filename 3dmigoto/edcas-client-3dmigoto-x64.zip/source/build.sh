#!/usr/bin/env bash
# Builds 3DMigoto's DirectX 11 DLL (d3d11.dll) on Linux with EDCAS's params-file patch,
# using clang-cl + lld-link against the MSVC runtime and Windows SDK from xwin:
#
#   cargo install --locked xwin
#   xwin --accept-license --arch x86_64 --variant desktop splat --copy --output ~/.xwin
#
# Usage: build.sh [build-dir]     (default: target/3dmigoto in the repo)
#        PATCH=0 build.sh <dir>   the same build without the patch, for comparisons
# Result: <build-dir>/out/d3d11.dll, ready to replace the d3d11.dll of a 3DMigoto install.
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO="$(cd "$HERE/../../.." && pwd)"
BUILD="$(realpath -m "${1:-$REPO/target/3dmigoto}")"
XWIN="${XWIN:-$HOME/.xwin}"
TAG=1.4.9   # the 3DMigoto release this patch is made for
SRC="$BUILD/src"
OBJ="$BUILD/obj"
OUT="$BUILD/out"
SHIM="$BUILD/case-shim"

[ -d "$XWIN/crt" ] || { echo "no MSVC runtime/SDK at $XWIN (see the top of this script)" >&2; exit 1; }

if [ ! -d "$SRC/.git" ]; then
	git clone -q --depth 1 --branch "$TAG" https://github.com/bo3b/3Dmigoto.git "$SRC"
fi
PATCH="${PATCH:-1}"
if [ "$PATCH" = 0 ]; then
	echo "building without the params-file patch"
elif [ -f "$SRC/DirectX11/ParamsFile.cpp" ]; then
	echo "patch already applied in $SRC"
else
	git -C "$SRC" apply "$HERE/params-file.patch"
fi

# As the Visual Studio project, minus _CRT_SECURE_CPP_OVERLOAD_STANDARD_NAMES(_COUNT): clang
# rejects the CRT's template overloads those switch on (they only swap strcpy and friends
# for their _s variants on fixed arrays).
DEFINES=(
	QUEUE_USE_CONFORMANT_NEW CRC32C_STATIC=1 PCRE2_STATIC PCRE2_CODE_UNIT_WIDTH=8
	_WINDOWS _USRDLL MIGOTO_DX=11 WIN32_LEAN_AND_MEAN _WIN32_WINNT=_WIN32_WINNT_WINBLUE NDEBUG
	UNICODE _UNICODE
)
INCLUDES=(
	"$SRC" "$SRC/DirectX11" "$SRC/HLSLDecompiler" "$SRC/BinaryDecompiler" "$SRC/BinaryDecompiler/include"
	"$SRC/ThirdPartyLibs/Nektra-lib" "$SRC/ThirdPartyLibs/nvapi-lib/nvapi-main"
	"$SRC/ThirdPartyLibs/pcre2-lib/pcre2_x64-windows-static/include"
	"$SRC/ThirdPartyLibs/DirectXTK-lib/include" "$SRC/D3D_Shaders" "$SRC/crc32c-hw-1.0.5/include" "$SHIM"
)
CFLAGS=(--target=x86_64-pc-windows-msvc /nologo /MT /O2 /EHsc /GS /Zc:wchar_t /W0
	-Wno-everything -fms-compatibility -fms-extensions
	/imsvc "$XWIN/crt/include" /imsvc "$XWIN/sdk/include/ucrt"
	/imsvc "$XWIN/sdk/include/um" /imsvc "$XWIN/sdk/include/shared" /imsvc "$XWIN/sdk/include/winrt")
for d in "${DEFINES[@]}"; do CFLAGS+=("/D$d"); done
for i in "${INCLUDES[@]}"; do CFLAGS+=("/I$i"); done

# Windows-only habits in the sources, rewritten for clang on Linux:
# - #includes spelled with a different letter case than the file: a folder of correctly
#   cased links (Windows file names are case-insensitive, Linux ones are not).
# - MSVC's "for each (x in list)" loops: the standard "for (x : list)".
# - Parameters named "default" (a keyword MSVC lets through): default_val.
# - A string literal kept in a non-const pointer, and a temporary passed by non-const
#   reference (both MSVC leniencies): made const.
# - cursor.cpp's variables named "and"/"xor": clang's -fno-operator-names (see compile()).
rm -rf "$SHIM"
python3 -I "$HERE/case_shim.py" "$SHIM" "$SRC" "${INCLUDES[@]}" \
	"$XWIN/crt/include" "$XWIN/sdk/include/ucrt" "$XWIN/sdk/include/um" "$XWIN/sdk/include/shared" "$XWIN/sdk/include/winrt"
{ grep -rlE '^\s*for each\s*\(' "$SRC" --include='*.cpp' --include='*.h' || true; } | while read -r f; do
	perl -pi -e 's/^(\s*)for each\s*\((.+?)\s+in\s+(.+)\)\s*$/$1for ($2 : $3)\n/' "$f"
done
perl -pi -e 's/\b(float|int|T2) default\b/$1 default_val/g; s/\breturn default;/return default_val;/g' \
	"$SRC/util.h" "$SRC/DirectX11/Override.cpp"
perl -pi -e 's/^(\s*)wchar_t \*wic_ext = /$1const wchar_t *wic_ext = /' "$SRC/DirectX11/FrameAnalysis.cpp"
perl -pi -e 's/globbing_vector_to_regex\(vector<wstring> &globbing_patterns\)/globbing_vector_to_regex(const vector<wstring> &globbing_patterns)/; s/prefix_upper_bound\(IniSections &sections, wstring &prefix\)/prefix_upper_bound(IniSections &sections, const wstring &prefix)/; s/vec_to_set\(std::vector<T> &v\)/vec_to_set(const std::vector<T> &v)/' \
	"$SRC/DirectX11/IniHandler.cpp"

# This list is also the link order, and the link order is the order the files' global
# constructors run in when the game loads the DLL. lock.cpp has to stay ahead of Overlay.cpp:
# Overlay's global "notices" registers its lock in lock.cpp's lock_names map while it is
# constructed (upstream's project file has them in this order too). Linked the other way
# round, DllMain crashes and the game does not start (0xc0000142). The objects were once
# linked as "$OBJ"/*.obj, whose order follows the locale: right under en_US, wrong under C.
SOURCES=(
	BinaryDecompiler/decode.cpp BinaryDecompiler/decodeDX9.cpp BinaryDecompiler/reflect.cpp
	crc32c-hw-1.0.5/src/crc32c.cpp D3D_Shaders/Assembler.cpp D3D_Shaders/SignatureParser.cpp
)
for f in CommandList cursor D3D11Wrapper DLLMainHook FrameAnalysis HackerContext HackerDevice \
	HackerDXGI; do
	SOURCES+=("DirectX11/$f.cpp")
done
SOURCES+=(DirectX11/HookAddresses.c)
for f in HookedContext HookedDevice HookedDXGI Hunting IniHandler input lock nvprofile \
	Overlay Override; do
	SOURCES+=("DirectX11/$f.cpp")
done
[ "$PATCH" = 0 ] || SOURCES+=(DirectX11/ParamsFile.cpp)
SOURCES+=(DirectX11/profiling.cpp DirectX11/ResourceHash.cpp DirectX11/ShaderRegex.cpp)
SOURCES+=(HLSLDecompiler/DecompileHLSL.cpp iid.cpp ini_parser_lite.cpp util.cpp)

mkdir -p "$OBJ" "$OUT"
obj_of() { echo "$OBJ/$(echo "$1" | tr '/' '_').obj"; }
compile() {
	local src="$1" obj
	obj="$(obj_of "$1")"
	local extra=()
	case "$src" in
	crc32c-hw-*) extra=(-msse4.2) ;;  # SSE 4.2 CRC32 intrinsics
	DirectX11/cursor.cpp) extra=(/clang:-fno-operator-names) ;;
	esac
	if [ ! -f "$obj" ] || [ "$SRC/$src" -nt "$obj" ]; then
		clang-cl "${CFLAGS[@]}" "${extra[@]}" /c "$SRC/$src" /Fo"$obj" > "$obj.log" 2>&1 || { echo "FAILED $src: $(grep -m3 -E "error" "$obj.log" | tr "\n" " ")" >&2; return 1; }
	fi
}
failed=0
for s in "${SOURCES[@]}"; do
	compile "$s" &
	while [ "$(jobs -rp | wc -l)" -ge "$(nproc)" ]; do wait -n || failed=1; done
done
while [ "$(jobs -rp | wc -l)" -gt 0 ]; do wait -n || failed=1; done
[ "$failed" = 0 ] || { echo "compile failed" >&2; exit 1; }

LIBS=(
	"$SRC/ThirdPartyLibs/Nektra-lib/NktHookLib64.lib"
	"$SRC/ThirdPartyLibs/nvapi-lib/nvapi-main/amd64/nvapi64.lib"
	"$SRC/ThirdPartyLibs/pcre2-lib/pcre2_x64-windows-static/lib/pcre2-8.lib"
	"$SRC/ThirdPartyLibs/DirectXTK-lib/lib/x64/Release/DirectXTK.lib"
	xinput9_1_0.lib d3dcompiler.lib dxgi.lib shlwapi.lib dbghelp.lib
	kernel32.lib user32.lib gdi32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib
)
OBJECTS=()
for s in "${SOURCES[@]}"; do OBJECTS+=("$(obj_of "$s")"); done
lld-link /nologo /DLL /MACHINE:X64 /OUT:"$OUT/d3d11.dll" /DEF:"$SRC/DirectX11/d3d11Wrapper.def" \
	/LIBPATH:"$XWIN/crt/lib/x86_64" /LIBPATH:"$XWIN/sdk/lib/um/x86_64" /LIBPATH:"$XWIN/sdk/lib/ucrt/x86_64" \
	"${OBJECTS[@]}" "${LIBS[@]}"
echo "built $OUT/d3d11.dll"
