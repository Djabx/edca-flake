"""Make 3DMigoto's #includes resolve on a case-sensitive file system.

Windows does not care whether a source writes "Overlay.h" or "overlay.h"; Linux does. For
every #include in the sources that does not match a file with its exact spelling, this links
the spelling the source asked for to the file that exists, inside a shim folder that the
build adds to the include path.

Usage: case_shim.py <shim-dir> <source-dir> <include-dir>...
"""
import os
import re
import sys

shim, src, *include_dirs = sys.argv[1:]
INCLUDE = re.compile(r'^\s*#\s*include\s*[<"]([^>"]+)[>"]', re.M)


def find_exact(name, dirs):
    return any(os.path.isfile(os.path.join(d, name)) for d in dirs)


def find_any_case(name, dirs):
    """The real path of `name` under one of `dirs`, matching each path part case-insensitively."""
    for d in dirs:
        path = d
        for part in name.replace('\\', '/').split('/'):
            if part in ('.', '..'):
                path = os.path.normpath(os.path.join(path, part))
                continue
            try:
                match = next((e for e in os.listdir(path) if e.lower() == part.lower()), None)
            except (FileNotFoundError, NotADirectoryError):
                match = None
            if match is None:
                break
            path = os.path.join(path, match)
        else:
            if os.path.isfile(path):
                return path
    return None


made = 0
for root, _, files in os.walk(src):
    for f in files:
        if not f.lower().endswith(('.c', '.cpp', '.h', '.hpp', '.inl')):
            continue
        text = open(os.path.join(root, f), encoding='utf-8', errors='replace').read()
        for name in INCLUDE.findall(text):
            dirs = [root, *include_dirs]
            if find_exact(name, dirs):
                continue
            real = find_any_case(name, dirs)
            if real is None:
                continue  # an optional or platform header; the compiler reports it if needed
            # A path like "../util.h" resolves next to the including file; link it there by
            # its plain name, which the shim folder on the include path then supplies.
            link = os.path.join(shim, os.path.basename(name.replace('\\', '/')))
            if os.path.lexists(link):
                continue
            os.makedirs(os.path.dirname(link), exist_ok=True)
            os.symlink(real, link)
            made += 1
print(f'case shim: {made} links')
